#!/usr/bin/env python

import os

_ITEM_MAP = {}

def init():
    fpath = os.path.join(os.path.dirname(__file__), 'inv-items.dat')