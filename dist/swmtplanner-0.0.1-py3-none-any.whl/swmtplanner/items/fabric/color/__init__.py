#!/usr/bin/env python

from .color import Shade, EMPTY, HEAVYSTRIP, STRIP, LIGHT, MEDIUM, BLACK, \
    Color

__all__ = ['Shade', 'EMPTY', 'HEAVYSTRIP', 'STRIP', 'LIGHT', 'MEDIUM',
           'BLACK', 'Color']