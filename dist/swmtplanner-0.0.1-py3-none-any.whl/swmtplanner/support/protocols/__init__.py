#!/usr/bin/env python

from .hasid import HasID

__all__ = ['HasID']