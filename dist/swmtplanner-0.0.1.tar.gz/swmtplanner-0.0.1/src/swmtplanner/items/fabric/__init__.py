#!/usr/bin/env python

from . import color
from .color import Color

__all__ = ['color', 'Color']