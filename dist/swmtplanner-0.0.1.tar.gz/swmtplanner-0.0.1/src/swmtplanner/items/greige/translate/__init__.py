#!/usr/bin/env python

from .translate import init, translate_name

__all__ = ['init', 'translate_name']