#!/usr/bin/env python

import pandas as pd, re, math, datetime as dt

from .info import INFO_MAP
from ._updates import df_cols_as_str

def _get_alt_item1(row):
    if pd.isna(row['Nominal\nWidth']):
        return row['Item']
    wd = row['Nominal\nWidth']
    if int(wd) == wd:
        return f'{row['Item']}-{int(wd)}'
    return f'{row['Item']}-{wd}'

def _get_alt_item2(row):
        if row['Code'] == '' or row['Style'] == '' or row['Color'] == '':
            return row['Item']
        if pd.isna(row['Width']):
            return row['Item']

        if int(row['Width']) == row['Width']:
            wd = str(int(row['Width']))
        else:
            wd = str(row['Width'])
        return f'FF {row['Style']}-{row['Color']}-{wd}'

def _get_style(item):
    comps = item.split('-')
    if len(comps) < 2:
        return ''
        
    start = comps[0].split(' ')
    if len(start) < 2:
        return ''
        
    return '-'.join([start[1]] + comps[1:-1])

def _get_color(item):
    comps = item.split('-')
    if len(comps) < 2 or len(comps[-1]) > 5:
        return ''

    return comps[-1]

def _load_pa_floor_mos():
    fpath, pdargs = INFO_MAP['pa_floor_mos']
    mo_df: pd.DataFrame = pd.read_excel(fpath, **pdargs)
    mo_df = df_cols_as_str(mo_df, 'Item\nType', 'Warehouse', 'Customer',
                           'Roll', 'Lot', 'Item', 'Quality', 'Grade', 'Owner',
                           'DEFECT1', 'DEF1_REASON', 'DEFECT2', 'DEF2_REASON',
                           'DEFECT3', 'DEF3_REASON', 'MARKET_SEGMENT')
    
    fin = mo_df['Warehouse'] == 'F1'
    pending = mo_df['Warehouse'] == 'FF'
    pack = mo_df['Warehouse'] == 'BP'
    insp = mo_df['Warehouse'] == 'BG'
    frame = mo_df['Warehouse'] == 'BF'
    slit = mo_df['Warehouse'] == 'BS'
    rework = mo_df['Warehouse'] == 'RW'
    mo_df = mo_df[fin | pending | pack | insp | frame | slit | rework]
    mo_df = mo_df[(mo_df['Lot'] != '0') & (pd.isna(mo_df['Grade']) | (mo_df['Grade'] != 'LOC'))]

    mo_df['Item2'] = mo_df[['Nominal\nWidth', 'Item']].agg(_get_alt_item1, axis=1).astype('string')
    mo_df['Style'] = mo_df['Item'].apply(_get_style).astype('string')
    mo_df['Color'] = mo_df['Item'].apply(_get_color).astype('string')
    mo_df['Process'] = mo_df['Warehouse'].apply(_map_warehouse).astype('string')

    return mo_df

def _load_dye_orders1():
    schedpath, schedargs = INFO_MAP['adaptive2_orders']
    adaptive: pd.DataFrame = pd.read_excel(schedpath, **schedargs)

    dye_data = {
        'job': [], 'dyelot': [], 'machine': [], 'start': [], 'end': []
    }
    for i in adaptive.index:
        if pd.isna(adaptive.loc[i, 'StartTime']): continue
        if pd.isna(adaptive.loc[i, 'EndTime']): continue
        
        job_id = adaptive.loc[i, 'JobID']
        if ', ' in job_id:
            lots = job_id.split('@')[0].split(', ')
        else:
            lots = job_id.split('@')[0].split('/')
        
        for lot in lots:
            if re.match('[0-9]{9}0', lot):
                dye_data['job'].append(job_id)
                dye_data['dyelot'].append(lot)
                dye_data['machine'].append(adaptive.loc[i, 'Machine'])
                dye_data['start'].append(adaptive.loc[i, 'StartTime'])
                dye_data['end'].append(adaptive.loc[i, 'EndTime'])
    
    dye_df = pd.DataFrame(data=dye_data)
    return dye_df

def _load_dye_orders2():
    dyepath, dyeargs = INFO_MAP['adaptive1_orders']
    dye_df: pd.DataFrame = pd.read_excel(dyepath, **dyeargs, dtype={'dyelot': 'string'})

    to_drop = dye_df[dye_df['item1'].isna() | (dye_df['Customer'] != 17191) | (dye_df['double?'] == 'Yes')].index
    dye_df = dye_df.drop(to_drop)
    dye_df = dye_df.sort_values('start')

    return dye_df

def _map_warehouse(wh):
    match wh:
        case 'BG':
            return 'INSPECTION'
        case 'BF':
            return 'FRAME'
        case 'BS':
            return 'SLITTER'
        case 'RW':
            return 'REWORK'
        case 'BP':
            return 'PACKING'
        case 'FF':
            return 'PENDING'
        case 'F1':
            return 'CAN SHIP'
    return 'NONE'

def _pa_dmnd_report(writer):
    dmnd_path, dmnd_args = INFO_MAP['lam_release']
    rls_df: pd.DataFrame = pd.read_excel(dmnd_path, **dmnd_args)
    to_drop = rls_df[rls_df['PA Item'].isna() | rls_df['Active?'].isna() | (rls_df['PA Item'] == 0)]
    rls_df = rls_df.drop(to_drop.index)

    rls_items = []
    rls_data = {
        'lam_item': [], 'plant': [], 'ply1_item': [], 'pa_item': [], 'pull': [],
        'lam_on_hand': [], 'lam_cc': [], 'ph_raw': [], 'ply1_on_hand': [],
        'sch_past_due': []
    }
    for i in range(3):
        rls_data[f'sch{i}'] = []
    rls_data['rls_past_due'] = []
    for i in range(9):
        rls_data[f'rls{i}'] = []
    rls_data['sched_day'] = []

    for item, grp in rls_df.groupby('Stock Item'):
        rls_items.append(item)
        pairs = [('lam_item', 'Lam Item'), ('plant', 'Plant'), ('ply1_item', 'Ply1 Item'),
            ('pa_item', 'PA Item'), ('pull', 'Add\'l pull (weeks)'),
            ('lam_on_hand', 'Lam On-Hand'), ('lam_cc', 'Lam Cust Contain GP12'),
            ('ph_raw', 'PH Raw'), ('ply1_on_hand', 'Ply1 On-Hand')]

        wl_fact = max(grp['LAM add\'l WL factor'])
        conv_fact = max(grp['Conversion to Yards'])

        for dest, src in pairs:
            rls_data[dest].append(max(grp[src]))

        rls_data['sch_past_due'].append(max(grp['SCH PD']) * wl_fact)
        for i in range(3):
            rls_data[f'sch{i}'].append(max(grp[f'SCH+{i}']) * wl_fact)

        rls_total = max(grp['Past Due']) - max(grp['Total Inv'])
        rls_data['rls_past_due'].append(max(0, rls_total) * conv_fact * wl_fact)
        for i in range(9):
            cur_rls = max(grp[f'RLS+{i}'])
            rls_total += cur_rls
            rls_data[f'rls{i}'].append(max(0, min(cur_rls, rls_total)) * conv_fact * wl_fact)

        rls_data['sched_day'].append(min(grp['Schedule Day']))

    stock_df = pd.DataFrame(data=rls_data, index=rls_items)
    lam_items = []
    lam_data = {
        'plant': [], 'ply1_item': [], 'pa_item': [], 'ph_raw': [], 'ply1_on_hand': [], 'past_due': []
    }
    for i in range(7):
        lam_data[f'wk{i}'] = []
    lam_data['sched_day'] = []

    for lam, grp in stock_df.groupby('lam_item'):
        lam_items.append(lam)
        max_cols = ['plant', 'ply1_item', 'pa_item', 'ph_raw', 'ply1_on_hand']
        pull = int(max(grp['pull']))

        for col in max_cols:
            lam_data[col].append(max(grp[col]))

        sch_total = max(grp['sch_past_due'])
        rls_total = sum(grp['rls_past_due']) - max(grp['lam_on_hand']) - max(grp['lam_cc'])
        for i in range(pull):
            sch_total += max(grp[f'sch{i}'])
            rls_total += sum(grp[f'rls{i}'])

        lam_data['past_due'].append(sch_total)
        for i in range(pull, 3):
            cur_sch = max(grp[f'sch{i}'])
            lam_data[f'wk{i-pull}'].append(cur_sch)
            sch_total += cur_sch
            rls_total += sum(grp[f'rls{i}'])

        rls_total -= sch_total
        for i in range(3, 7+pull):
            cur_rls = sum(grp[f'rls{i}'])
            rls_total += cur_rls
            if i == 3:
                cur_rls = rls_total
            lam_data[f'wk{i-pull}'].append(max(0, min(rls_total, cur_rls)))

        lam_data['sched_day'].append(min(grp['sched_day']))

    lam_df = pd.DataFrame(data=lam_data, index=lam_items)
    ply1_data1 = {
        'ply1_item': [], 'plant': [], 'pa_item': [], 'past_due': []
    }
    for i in range(7):
        ply1_data1[f'wk{i}'] = []
    ply1_data1['sched_day'] = []

    for key, grp in lam_df.groupby(['ply1_item', 'plant']):
        ply1, plant = key
        ply1_data1['ply1_item'].append(ply1)
        ply1_data1['plant'].append(plant)
        ply1_data1['pa_item'].append(max(grp['pa_item']))

        total_dmd = sum(grp['past_due']) - max(grp['ply1_on_hand']) - max(grp['ph_raw'])
        ply1_data1['past_due'].append(max(0, total_dmd))
        for i in range(7):
            cur_dmd = sum(grp[f'wk{i}'])
            total_dmd += cur_dmd
            ply1_data1[f'wk{i}'].append(max(0, min(total_dmd, cur_dmd)))

        ply1_data1['sched_day'].append(min(grp['sched_day']))

    ply1_df1 = pd.DataFrame(data=ply1_data1)
    join_plts = lambda a: "/".join([str(int(x)) for x in list(a)])

    ply1_df2 = ply1_df1.groupby('ply1_item').agg(
        plant = pd.NamedAgg('plant', join_plts),
        pa_item = pd.NamedAgg('pa_item', 'max'),
        sched_day = pd.NamedAgg('sched_day', 'min'),
        past_due = pd.NamedAgg('past_due', 'sum'),
        wk0 = pd.NamedAgg('wk0', 'sum'),
        wk1 = pd.NamedAgg('wk1', 'sum'),
        wk2 = pd.NamedAgg('wk2', 'sum'),
        wk3 = pd.NamedAgg('wk3', 'sum'),
        wk4 = pd.NamedAgg('wk4', 'sum'),
        wk5 = pd.NamedAgg('wk5', 'sum'),
        wk6 = pd.NamedAgg('wk6', 'sum')
    )

    mapper = {}
    caps = ['ply1_item', 'plant']
    fab_req = [f'wk{i}' for i in range(7)]

    for col in caps:
        words = col.split('_')
        words = [w[0].upper() + w[1:] for w in col.split('_')]
        mapper[col] = ' '.join(words)

    mapper['pa_item'] = 'PA Item'
    mapper['sched_day'] = 'Ship Day'
    mapper['past_due'] = 'FAB req\'d past due'

    for col in fab_req:
        mapper[col] = 'FAB req\'d ' + col.upper()

    ply1_df2 = ply1_df2.rename(columns=mapper)
    ply1_df2.to_excel(writer, sheet_name='Fab shortage', index_label='Ply1 Item')

def _pa_process_report(mo_df: pd.DataFrame, writer):
    get_code = lambda item: '' if item[2] != ' ' else item[:2]
    
    mo_df['ItemCode'] = mo_df['Item'].apply(get_code).astype('string')

    first = lambda srs: list(srs)[0]
    
    by_lot = mo_df.groupby(['Process', 'Lot', 'Quality']).agg(
        Code=pd.NamedAgg(column='ItemCode', aggfunc=first),
        Item=pd.NamedAgg(column='Item', aggfunc=first),
        Style=pd.NamedAgg(column='Style', aggfunc=first),
        Color=pd.NamedAgg(column='Color', aggfunc=first),
        Customer=pd.NamedAgg(column='Customer', aggfunc=first),
        Owner=pd.NamedAgg(column='Owner', aggfunc=first),
        Market=pd.NamedAgg(column='MARKET_SEGMENT', aggfunc=first),
        Width=pd.NamedAgg(column='Nominal\nWidth', aggfunc=first),
        Quantity=pd.NamedAgg(column='Quantity', aggfunc='sum'))
    by_lot = by_lot.reset_index()

    by_lot['AltItem'] = by_lot[['Code', 'Item', 'Style', 'Color', 'Width']].agg(_get_alt_item2, axis=1).astype('string')

    by_lot.to_excel(writer, sheet_name='summary', float_format='%.2f', index=False)

def _pa_rework_report(mo_df: pd.DataFrame, writer):
    rwk_df = mo_df[mo_df['Process'] == 'REWORK']
    rwk_df['Code'] = 'RW'
    rwk_df = rwk_df.rename({'Nominal\nWidth': 'Width', 'DEFECT1': 'Defect1',
                            'DEF1_REASON': 'Reason1', 'DEFECT2': 'Defect2',
                            'DEF2_REASON': 'Reason2', 'DEFECT3': 'Defect3',
                            'DEF3_REASON': 'Reason3', 'MARKET_SEGMENT': 'Market'}, axis=1)
    rwk_df['AltItem'] = rwk_df[['Code', 'Item', 'Style', 'Color', 'Width']].agg(_get_alt_item2, axis=1).astype('string')
    rwk_df.to_excel(writer, sheet_name='reworks', float_format='%.2f',
                    columns=['Customer', 'Owner', 'Width', 'Roll', 'Lot',
                             'Item', 'AltItem', 'Quality', 'Quantity',
                             'Defect1', 'Reason1', 'Defect2', 'Reason2',
                             'Defect3', 'Reason3', 'Market'], index=False)

def _parse_ship_day(day_str: str):
    day_str = day_str.lower()
    if 'every' in day_str or 'all' in day_str or 'any' in day_str:
        return { 'monday', 'tuesday', 'wednesday', 'thursday', 'friday' }

    main_pat = '[^a-z]*{}[^a-z]*'
    day_pats = {
        'monday': 'm(on(days?)?)?', 'tuesday': 't(u(e(s(days?)?)?)?)?',
        'wednesday': 'wed(nesdays?)?', 'thursday': 'th(ur(s(days?)?)?)?',
        'friday': 'f(ri(days?)?)?'
    }

    for day in day_pats:
        if re.match(main_pat.format(day_pats[day]), day_str) is not None:
            return day

    return None

def _parse_ship_days(days_str: str):
    if type(days_str) is not str:
        return set()
    
    comps = re.split(',|/|or|and', days_str)
    day_set = set()
    for comp in comps:
        day = _parse_ship_day(comp)
        if type(day) is set:
            return day
        elif day is None:
            print(f'could not parse {repr(comp)}')
        else:
            day_set.add(day)
    return day_set

def _map_ship_day(item, ship_days_data):
    if item in ship_days_data:
        return ship_days_data[item]
    return math.inf

def _sub_bsns_days(start: dt.datetime, ndays: int):
    while True:
        wkday = start.weekday()
        if ndays > wkday:
            start -= dt.timedelta(days=wkday+2)
            ndays -= wkday
        else:
            start -= dt.timedelta(days=ndays)
            return start

def _pa_priority_mos_report(start: dt.datetime, mo_df: pd.DataFrame, writer):
    shippath, shipargs = INFO_MAP['lam_ship_dates']
    ship_df: pd.DataFrame = pd.read_excel(shippath, **shipargs)
    ship_df = df_cols_as_str(ship_df, 'Stock Item', 'Ply1 Item', 'Ship Day')

    reqpath, reqargs = INFO_MAP['pa_reqs']
    reqs_df: pd.DataFrame = pd.read_excel(reqpath, **reqargs)
    reqs_df = df_cols_as_str(reqs_df, 'PA Item', 'Ply1 Item')
    to_drop = reqs_df[reqs_df['PA Item'].isna()].index
    reqs_df = reqs_df.drop(to_drop)

    ship_df = ship_df[ship_df['Ply1 Item'] != '0']

    days_map = {
        'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3, 'friday': 4
    }

    grouped = ship_df.groupby('Ply1 Item')
    ship_days_data = {}
    for name, group in grouped:
        ship_days = group['Ship Day'].unique()
        sched_day = min(group['Schedule Day'])
        
        day_set = set()
        for ship_str in ship_days:
            if not pd.isna(ship_str):
                day_set |= _parse_ship_days(ship_str)

        days = [math.inf] + list(map(lambda x: days_map[x], day_set))
        ship_days_data[name] = sched_day

    reqs_df['Ship Day'] = reqs_df['Ply1 Item'].apply(lambda x: _map_ship_day(x, ship_days_data))

    monday = start - dt.timedelta(days=start.weekday())
    monday = dt.datetime(monday.year, monday.month, monday.day)

    pairs = [(-1, 'past due')]
    for i in range(6):
        pairs.append((i, f'WK{i}'))

    req_data = {
        'plant': [], 'item': [], 'lam_item': [], 'pnum': [], 'due_date': [],
        'yds': [], 'cum_yds': []
    }

    for pa_item, grp in reqs_df.groupby('PA Item'):
        plant = '/'.join([str(x) for x in list(grp['Plant'])])
        lam_id = '/'.join([str(x) for x in list(grp['Ply1 Item'])])
        fab_id = pa_item
        if fab_id[:2] != 'FF': continue

        cum_req = -1 * sum(grp['In transit'])

        for wk_delta, col_end in pairs:
            req_raw = sum(grp[f'FAB req\'d {col_end}'])
            if col_end == 'past due':
                pnum = -1
            else:
                pnum = int(col_end[2:])
            wkday = min(grp['Ship Day']) - 2
            if wkday == math.inf:
                wkday = 2

            lam_due_date = monday + dt.timedelta(weeks=wk_delta, days=wkday)
            due_date = _sub_bsns_days(lam_due_date, 5)

            cum_req += req_raw
            cur_req_yds = max(0, min(req_raw, cum_req))

            if cur_req_yds > 100:
                req_data['plant'].append(plant)
                req_data['lam_item'].append(lam_id)
                req_data['item'].append(fab_id)
                req_data['pnum'].append(pnum)
                req_data['due_date'].append(due_date)
                req_data['yds'].append(cur_req_yds)
                req_data['cum_yds'].append(cum_req)
    
    orders_df = pd.DataFrame(data=req_data)
    orders_df = df_cols_as_str(orders_df, 'item')

    dye_df = _load_dye_orders2()

    first = lambda srs: list(srs)[0]
    mo_df = mo_df[mo_df['Customer'].str.match('0171910.*') & (mo_df['Quality'] == 'A')
                  & ((mo_df['Grade'] != 'REJ') | pd.isna(mo_df['Grade']))]
    mo_grp_df = mo_df.groupby(['Lot', 'Nominal\nWidth']).agg(
        Warehouse=pd.NamedAgg('Warehouse', first),
        Item=pd.NamedAgg('Item', first),
        ItemWidth=pd.NamedAgg('Item2', first),
        Quantity=pd.NamedAgg('Quantity', 'sum')
    )
    mo_df = mo_grp_df.reset_index()

    mo_data = {
        'mo': [], 'warehouse': [], 'plant': [], 'lam_item': [], 'pa_item': [], 'raw_yds': [],
        'fin_yds_expected': [], 'ordered_yds': [], 'pnum': [], 'due_date': []
    }
    added_mos: set[tuple[str, str]] = set()

    for pa_item in orders_df['item'].unique():
        order_idxs = list(orders_df[orders_df['item'] == pa_item].index)
        mo_idxs = []
        dye_idxs = []
        for proc in ('F1', 'FF', 'BP', 'BG'):
            sub_df = mo_df[(mo_df['ItemWidth'] == pa_item) & (mo_df['Warehouse'] == proc)]
            mo_idxs += list(sub_df.index)

        try:
            item_comps = pa_item.split('-')
            item_no_wd = '-'.join(item_comps[:-1])
            item_wd = float(item_comps[-1])
        except:
            continue

        for proc in ('BF', 'BS'):
            sub_df = mo_df[(mo_df['Item'] == item_no_wd) & (mo_df['Warehouse'] == proc)]
            wd2_df = sub_df[sub_df['Nominal\nWidth'] == item_wd*2]
            wd3_df = sub_df[sub_df['Nominal\nWidth'] == item_wd*3]
            mo_idxs += list(wd2_df.index)
            mo_idxs += list(wd3_df.index)
        
        sub_df = dye_df[(dye_df['item1'] == pa_item) | (dye_df['item2'] == pa_item)]
        dye_idxs = list(sub_df.index)

        i, j, k = 0, 0, 0
        total_prod, total_req = 0, 0
        while i < len(order_idxs) and (j < len(mo_idxs) or k < len(dye_idxs)):
            o_idx = order_idxs[i]
            if j < len(mo_idxs):
                m_idx = mo_idxs[j]
                d_idx = -1
            else:
                m_idx = -1
                d_idx = dye_idxs[k]

            pa_item = orders_df.loc[o_idx, 'item']
            lam_item = orders_df.loc[o_idx, 'lam_item']
            plant = orders_df.loc[o_idx, 'plant']
            item_wd = float(pa_item.split('-')[-1])

            if m_idx >= 0:
                true_qty = mo_df.loc[m_idx, 'Quantity']
                if mo_df.loc[m_idx, 'Warehouse'] in ('BF', 'BS'):
                    if mo_df.loc[m_idx, 'Nominal\nWidth'] == item_wd*2:
                        true_qty *= 2 * 0.85
                    elif mo_df.loc[m_idx, 'Nominal\nWidth'] == item_wd*3:
                        true_qty *= 3 * 0.85
                elif mo_df.loc[m_idx, 'Warehouse'] == 'BG':
                    true_qty *= 0.9

                rem_qty = total_req + orders_df.loc[o_idx, 'yds'] - total_prod
                cur_pair = (mo_df.loc[m_idx, 'Lot'], mo_df.loc[m_idx, 'Warehouse'])
            else:
                true_qty = dye_df.loc[d_idx, 'qty'] * 0.85
                rem_qty = total_req + orders_df.loc[o_idx, 'yds'] - total_prod
                cur_pair = (dye_df.loc[d_idx, 'dyelot'], 'DYEHOUSE')

            if rem_qty >= 100 and cur_pair not in added_mos:
                added_mos.add(cur_pair)
                mo_data['mo'].append(cur_pair[0])
                mo_data['warehouse'].append(cur_pair[1])
                mo_data['plant'].append(plant)
                mo_data['lam_item'].append(lam_item)
                mo_data['pa_item'].append(pa_item)
                if m_idx >= 0:
                    mo_data['raw_yds'].append(mo_df.loc[m_idx, 'Quantity'])
                else:
                    mo_data['raw_yds'].append(dye_df.loc[d_idx, 'qty'] / dye_df.loc[d_idx, 'panels'])
                mo_data['fin_yds_expected'].append(true_qty)
                mo_data['ordered_yds'].append(orders_df.loc[o_idx, 'yds'])
                mo_data['pnum'].append(orders_df.loc[o_idx, 'pnum'])
                mo_data['due_date'].append(orders_df.loc[o_idx, 'due_date'])

            if total_prod + true_qty >= total_req + orders_df.loc[o_idx, 'yds']:
                total_req += orders_df.loc[o_idx, 'yds']
                i += 1
            else:
                total_prod += true_qty
                if j < len(mo_idxs):
                    j += 1
                else:
                    k += 1
    
    prty_mo_df = pd.DataFrame(data=mo_data)
    prty_mo_df = df_cols_as_str(prty_mo_df, 'mo', 'warehouse', 'lam_item', 'pa_item')

    prty_mo_df.to_excel(writer, sheet_name='mo_priorities', float_format='%.2f',
                        index=False)
    orders_df.to_excel(writer, sheet_name='demand', float_format='%.2f',
                       index=False)